#import "HUDRootViewController.h"
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "./SCLAlertView/SCLAlertView.h"

// تعريف المتغيرات العالمية
static id menu = nil;
static id switches = nil;

// الماكروت المطلوبة
#define timer(sec, block) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, sec * NSEC_PER_SEC), dispatch_get_main_queue(), block)
#define UIColorFromHex(hexColor) [UIColor colorWithRed:((float)((hexColor & 0xFF0000) >> 16))/255.0 green:((float)((hexColor & 0xFF00) >> 8))/255.0 blue:((float)(hexColor & 0xFF))/255.0 alpha:1.0]

// كلاس Slider Button
@interface SliderButton : UIButton
@property (nonatomic, strong) NSString *sliderName;
@property (nonatomic, strong) NSString *sliderDescription;
@property (nonatomic, assign) CGFloat sliderValue;
@property (nonatomic, strong) UISlider *slider;
@property (nonatomic, strong) UILabel *valueLabel;
@end

@implementation SliderButton

- (instancetype)initWithFrame:(CGRect)frame name:(NSString *)name description:(NSString *)description {
    self = [super initWithFrame:frame];
    if (self) {
        _sliderName = name;
        _sliderDescription = description;
        _sliderValue = 50.0;
        
        [self setupSlider];
    }
    return self;
}

- (void)setupSlider {
    self.backgroundColor = [UIColor darkGrayColor];
    self.layer.cornerRadius = 10;
    self.layer.borderWidth = 1;
    self.layer.borderColor = [UIColor whiteColor].CGColor;
    
    // Title Label
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, self.frame.size.width - 20, 15)];
    titleLabel.text = _sliderName;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate-Bold" size:12];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:titleLabel];
    
    // Slider
    _slider = [[UISlider alloc] initWithFrame:CGRectMake(10, 25, self.frame.size.width - 80, 20)];
    _slider.minimumValue = 0.0;
    _slider.maximumValue = 100.0;
    _slider.value = _sliderValue;
    _slider.minimumTrackTintColor = UIColorFromHex(0x00ADF2);
    _slider.maximumTrackTintColor = [UIColor lightGrayColor];
    [_slider addTarget:self action:@selector(sliderValueChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_slider];
    
    // Value Label
    _valueLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.frame.size.width - 60, 25, 50, 20)];
    _valueLabel.text = [NSString stringWithFormat:@"%.0f", _sliderValue];
    _valueLabel.textColor = [UIColor whiteColor];
    _valueLabel.font = [UIFont fontWithName:@"Copperplate-Bold" size:12];
    _valueLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:_valueLabel];
    
    // Info button
    UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
    infoButton.frame = CGRectMake(self.frame.size.width - 25, 5, 15, 15);
    infoButton.tintColor = [UIColor whiteColor];
    [infoButton addTarget:self action:@selector(showInfo) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:infoButton];
}

- (void)sliderValueChanged:(UISlider *)slider {
    _sliderValue = slider.value;
    _valueLabel.text = [NSString stringWithFormat:@"%.0f", _sliderValue];
    
    // تحديث قيمة السلايدر في الـ switches manager
    if (switches) {
        SEL updateSelector = NSSelectorFromString(@"setSliderValue:value:");
        if ([switches respondsToSelector:updateSelector]) {
            ((void (*)(id, SEL, NSString *, CGFloat))[switches methodForSelector:updateSelector])(switches, updateSelector, _sliderName, _sliderValue);
        }
    }
}

- (void)showInfo {
    // يمكن إضافة عرض المعلومات هنا إذا needed
}

@end

// كلاس Switch Button
@interface SwitchButton : UIButton
@property (nonatomic, strong) NSString *switchName;
@property (nonatomic, strong) NSString *switchDescription;
@property (nonatomic, assign) BOOL isOn;
@property (nonatomic, strong) UIColor *onColor;
@property (nonatomic, strong) UIColor *offColor;
@end

@implementation SwitchButton

- (instancetype)initWithFrame:(CGRect)frame name:(NSString *)name description:(NSString *)description onColor:(UIColor *)onColor offColor:(UIColor *)offColor {
    self = [super initWithFrame:frame];
    if (self) {
        _switchName = name;
        _switchDescription = description;
        _onColor = onColor;
        _offColor = offColor;
        _isOn = NO;
        
        [self setupButton];
    }
    return self;
}

- (void)setupButton {
    self.backgroundColor = _offColor;
    self.layer.cornerRadius = 10;
    self.layer.borderWidth = 1;
    self.layer.borderColor = [UIColor whiteColor].CGColor;
    
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, self.frame.size.width - 60, self.frame.size.height)];
    titleLabel.text = _switchName;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont fontWithName:@"Copperplate-Bold" size:16];
    titleLabel.textAlignment = NSTextAlignmentLeft;
    [self addSubview:titleLabel];
    
    // Info button
    UIButton *infoButton = [UIButton buttonWithType:UIButtonTypeInfoLight];
    infoButton.frame = CGRectMake(self.frame.size.width - 40, 10, 20, 20);
    infoButton.tintColor = [UIColor whiteColor];
    [infoButton addTarget:self action:@selector(showInfo) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:infoButton];
    
    // Status indicator
    UIView *statusView = [[UIView alloc] initWithFrame:CGRectMake(self.frame.size.width - 20, 15, 10, 10)];
    statusView.backgroundColor = [UIColor redColor];
    statusView.layer.cornerRadius = 5;
    statusView.tag = 100;
    [self addSubview:statusView];
}

- (void)showInfo {
    // يمكن إضافة عرض المعلومات هنا إذا needed
}

- (void)toggleSwitch {
    _isOn = !_isOn;
    
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundColor = self.isOn ? self.onColor : self.offColor;
        
        UIView *statusView = [self viewWithTag:100];
        statusView.backgroundColor = self.isOn ? [UIColor greenColor] : [UIColor redColor];
    }];
}

@end

// كلاس Menu مبسط
@interface SimpleMenu : UIView
@property (nonatomic, strong) UIButton *menuButton;
@property (nonatomic, strong) UIView *menuView;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, assign) BOOL isMenuVisible;
@property (nonatomic, strong) NSMutableArray *switchButtons;
@property (nonatomic, strong) NSMutableArray *sliderButtons;
@property (nonatomic, strong) UIColor *switchOnColor;
@property (nonatomic, strong) UIColor *switchOffColor;
@property (nonatomic, strong) UIPanGestureRecognizer *menuPanGesture;
@end

@implementation SimpleMenu

- (instancetype)initWithTitle:(NSString *)title
                   titleColor:(UIColor *)titleColor
                    titleFont:(NSString *)titleFont
                      credits:(NSString *)credits
                  headerColor:(UIColor *)headerColor
               switchOffColor:(UIColor *)switchOffColor
                switchOnColor:(UIColor *)switchOnColor
             switchTitleFont:(NSString *)switchTitleFont
            switchTitleColor:(UIColor *)switchTitleColor
             infoButtonColor:(UIColor *)infoButtonColor
           maxVisibleSwitches:(int)maxVisibleSwitches
                    menuWidth:(CGFloat)menuWidth
                    menuIcon:(NSString *)menuIcon
                   menuButton:(NSString *)menuButton {
    
    self = [super initWithFrame:[UIScreen mainScreen].bounds];
    if (self) {
        _switchOnColor = switchOnColor;
        _switchOffColor = switchOffColor;
        _switchButtons = [NSMutableArray array];
        _sliderButtons = [NSMutableArray array];
        
        self.backgroundColor = [UIColor clearColor];
        [self setupMenuViewWithTitle:title titleColor:titleColor headerColor:headerColor menuWidth:menuWidth maxVisibleSwitches:maxVisibleSwitches];
        [self setupMenuButton];
        [self addSwitchesToMenu];
    }
    return self;
}

- (void)setupMenuViewWithTitle:(NSString *)title titleColor:(UIColor *)titleColor headerColor:(UIColor *)headerColor menuWidth:(CGFloat)menuWidth maxVisibleSwitches:(int)maxVisibleSwitches {
    CGFloat menuHeight = 50 + (4 * 55) + 10; // 4 أزرار فقط
    
    _menuView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, menuWidth, menuHeight)];
    _menuView.center = self.center;
    _menuView.backgroundColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.2 alpha:0.95];
    _menuView.layer.cornerRadius = 15;
    _menuView.layer.borderWidth = 2;
    _menuView.layer.borderColor = headerColor.CGColor;
    _menuView.layer.shadowColor = [UIColor blackColor].CGColor;
    _menuView.layer.shadowOffset = CGSizeMake(0, 5);
    _menuView.layer.shadowOpacity = 0.5;
    _menuView.layer.shadowRadius = 10;
    _menuView.alpha = 0;
    _menuView.transform = CGAffineTransformMakeScale(0.5, 0.5);
    
    // إضافة زوايا دائرية للأسفل
    _menuView.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner | kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner;
    
    // إضافة إمكانية السحب للقائمة
    _menuPanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleMenuPan:)];
    [_menuView addGestureRecognizer:_menuPanGesture];
    
    // Header
    UIView *header = [[UIView alloc] initWithFrame:CGRectMake(0, 0, menuWidth, 50)];
    header.backgroundColor = headerColor;
    header.layer.cornerRadius = 15;
    header.layer.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
    
    // Title
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, menuWidth - 20, 50)];
    titleLabel.text = title;
    titleLabel.textColor = titleColor;
    titleLabel.font = [UIFont fontWithName:@"Copperplate-Bold" size:18];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [header addSubview:titleLabel];
    
    // Close button
    UIButton *closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    closeButton.frame = CGRectMake(menuWidth - 40, 10, 30, 30);
    [closeButton setTitle:@"X" forState:UIControlStateNormal];
    [closeButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    closeButton.titleLabel.font = [UIFont boldSystemFontOfSize:16];
    [closeButton addTarget:self action:@selector(hideMenu) forControlEvents:UIControlEventTouchUpInside];
    [header addSubview:closeButton];
    
    [_menuView addSubview:header];
    
    // Scroll View for switches
    _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 50, menuWidth, menuHeight - 50)];
    _scrollView.backgroundColor = _switchOffColor;
    _scrollView.showsVerticalScrollIndicator = YES;
    _scrollView.alwaysBounceVertical = YES;
    _scrollView.layer.cornerRadius = 15;
    _scrollView.layer.maskedCorners = kCALayerMinXMaxYCorner | kCALayerMaxXMaxYCorner;
    [_menuView addSubview:_scrollView];
    
    [self addSubview:_menuView];
}

- (void)addSwitchesToMenu {
    // 4 أزرار فقط كما طلبت
    NSArray *switchNames = @[
        @{@"name": @"AIMBOT", @"desc": @"Aimbot feature", @"type": @"switch"},
        @{@"name": @"AIM FOV", @"desc": @"Aim field of view", @"type": @"slider"},
        @{@"name": @"LINE", @"desc": @"Line feature", @"type": @"switch"},
        @{@"name": @"BOX", @"desc": @"Box feature", @"type": @"switch"}
    ];
    
    CGFloat yPosition = 10;
    for (NSDictionary *switchInfo in switchNames) {
        if ([switchInfo[@"type"] isEqualToString:@"switch"]) {
            SwitchButton *switchBtn = [[SwitchButton alloc] initWithFrame:CGRectMake(20, yPosition, _scrollView.frame.size.width - 40, 45)
                                                                     name:switchInfo[@"name"]
                                                              description:switchInfo[@"desc"]
                                                                  onColor:_switchOnColor
                                                                 offColor:_switchOffColor];
            
            [switchBtn addTarget:self action:@selector(switchButtonTapped:) forControlEvents:UIControlEventTouchUpInside];
            [_scrollView addSubview:switchBtn];
            [_switchButtons addObject:switchBtn];
        } else if ([switchInfo[@"type"] isEqualToString:@"slider"]) {
            SliderButton *sliderBtn = [[SliderButton alloc] initWithFrame:CGRectMake(20, yPosition, _scrollView.frame.size.width - 40, 50)
                                                                     name:switchInfo[@"name"]
                                                              description:switchInfo[@"desc"]];
            
            [_scrollView addSubview:sliderBtn];
            [_sliderButtons addObject:sliderBtn];
        }
        
        yPosition += 55;
    }
    
    // Set scroll view content size
    _scrollView.contentSize = CGSizeMake(_scrollView.frame.size.width, yPosition + 10);
}

- (void)switchButtonTapped:(SwitchButton *)sender {
    [sender toggleSwitch];
    
    // تحديث حالة السويتش في الـ switches manager
    if (switches) {
        SEL updateSelector = NSSelectorFromString(@"setSwitchState:isOn:");
        if ([switches respondsToSelector:updateSelector]) {
            ((void (*)(id, SEL, NSString *, BOOL))[switches methodForSelector:updateSelector])(switches, updateSelector, sender.switchName, sender.isOn);
        }
    }
}

- (void)setupMenuButton {
    _menuButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _menuButton.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 70, 150, 60, 60);
    _menuButton.backgroundColor = UIColorFromHex(0xBD0000);
    [_menuButton setTitle:@"MOD" forState:UIControlStateNormal];
    [_menuButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    _menuButton.titleLabel.font = [UIFont boldSystemFontOfSize:14];
    _menuButton.layer.cornerRadius = 30; // زوايا دائرية للزر
    _menuButton.layer.borderWidth = 2;
    _menuButton.layer.borderColor = [UIColor whiteColor].CGColor;
    _menuButton.alpha = 0.8;
    
    [_menuButton addTarget:self action:@selector(showMenu) forControlEvents:UIControlEventTouchUpInside];
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleButtonPan:)];
    [_menuButton addGestureRecognizer:panGesture];
    
    [self addSubview:_menuButton];
}

- (void)showMenu {
    if (_isMenuVisible) return;
    
    _isMenuVisible = YES;
    
    [UIView animateWithDuration:0.6
                          delay:0
         usingSpringWithDamping:0.7
          initialSpringVelocity:0.5
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
        self.menuView.alpha = 1.0;
        self.menuView.transform = CGAffineTransformIdentity;
        self.menuButton.alpha = 0.0;
    } completion:nil];
}

- (void)hideMenu {
    if (!_isMenuVisible) return;
    
    _isMenuVisible = NO;
    
    [UIView animateWithDuration:0.4 animations:^{
        self.menuView.alpha = 0;
        self.menuView.transform = CGAffineTransformMakeScale(0.5, 0.5);
    } completion:^(BOOL finished) {
        [UIView animateWithDuration:0.3 animations:^{
            self.menuButton.alpha = 1.0;
        }];
    }];
}

- (void)handleButtonPan:(UIPanGestureRecognizer *)gesture {
    UIButton *button = (UIButton *)gesture.view;
    CGPoint translation = [gesture translationInView:button.superview];
    
    button.center = CGPointMake(button.center.x + translation.x, 
                               button.center.y + translation.y);
    [gesture setTranslation:CGPointZero inView:button.superview];
}

- (void)handleMenuPan:(UIPanGestureRecognizer *)gesture {
    UIView *menuView = gesture.view;
    CGPoint translation = [gesture translationInView:menuView.superview];
    
    menuView.center = CGPointMake(menuView.center.x + translation.x, 
                                 menuView.center.y + translation.y);
    [gesture setTranslation:CGPointZero inView:menuView.superview];
}

@end

// كلاس Switches مبسط
@interface SimpleSwitches : NSObject
- (BOOL)isSwitchOn:(NSString *)switchName;
- (void)addSwitch:(NSString *)name description:(NSString *)desc;
- (void)setSwitchState:(NSString *)switchName isOn:(BOOL)isOn;
- (void)setSliderValue:(NSString *)sliderName value:(CGFloat)value;
@end

@implementation SimpleSwitches {
    NSMutableDictionary *_switchStates;
    NSMutableDictionary *_switchDescriptions;
    NSMutableDictionary *_sliderValues;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _switchStates = [NSMutableDictionary dictionary];
        _switchDescriptions = [NSMutableDictionary dictionary];
        _sliderValues = [NSMutableDictionary dictionary];
    }
    return self;
}

- (BOOL)isSwitchOn:(NSString *)switchName {
    return [_switchStates[switchName] boolValue];
}

- (void)addSwitch:(NSString *)name description:(NSString *)desc {
    _switchStates[name] = @NO;
    _switchDescriptions[name] = desc;
    NSLog(@"Added switch: %@ - %@", name, desc);
}

- (void)setSwitchState:(NSString *)switchName isOn:(BOOL)isOn {
    _switchStates[switchName] = @(isOn);
    NSLog(@"Switch %@ is now %@", switchName, isOn ? @"ON" : @"OFF");
}

- (void)setSliderValue:(NSString *)sliderName value:(CGFloat)value {
    _sliderValues[sliderName] = @(value);
    NSLog(@"Slider %@ value: %.1f", sliderName, value);
}

@end

void setup() {
    @autoreleasepool {
        if (switches) {
            [switches addSwitch:@"AIMBOT" description:@"Aimbot feature"];
            [switches addSwitch:@"LINE" description:@"Line feature"];
            [switches addSwitch:@"BOX" description:@"Box feature"];
        }
    }
}

void setupMenu() {
    @autoreleasepool {
        if (!menu) {
            UIWindow *mainWindow = [UIApplication sharedApplication].keyWindow;
            
            menu = [[SimpleMenu alloc]  
                    initWithTitle:@"MOD MENU"
                    titleColor:[UIColor whiteColor]
                    titleFont:@"Copperplate-Bold"
                    credits:@""
                    headerColor:UIColorFromHex(0xBD0000)
                    switchOffColor:[UIColor darkGrayColor]
                    switchOnColor:UIColorFromHex(0x00ADF2)
                    switchTitleFont:@"Copperplate-Bold"
                    switchTitleColor:[UIColor whiteColor]
                    infoButtonColor:UIColorFromHex(0xBD0000)
                    maxVisibleSwitches:4
                    menuWidth:280
                    menuIcon:@""
                    menuButton:@""];    
            
            if (!switches) {
                switches = [[SimpleSwitches alloc] init];
            }
            
            [mainWindow addSubview:menu];
            
            setup();
        }
    }
}

// HUDRootViewController Implementation
@implementation HUDRootViewController {
    NSMutableArray <NSLayoutConstraint *> *_constraints;
    UIBlurEffect *_blurEffect;
    UIVisualEffectView *_blurView;
    UIView *_contentView;
    UIView *_redSquareView;
    CAShapeLayer *_redCircleLayer;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _constraints = [NSMutableArray array];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];

    _contentView = [[UIView alloc] init];
    _contentView.backgroundColor = [UIColor clearColor];
    _contentView.translatesAutoresizingMaskIntoConstraints = NO;
    [self.view addSubview:_contentView];

    _blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleDark];
    _blurView = [[UIVisualEffectView alloc] initWithEffect:_blurEffect];
    _blurView.layer.cornerRadius = 4.5;
    _blurView.layer.masksToBounds = YES;
    _blurView.translatesAutoresizingMaskIntoConstraints = NO;
    [_contentView addSubview:_blurView];

    // إزالة المربع الأحمر وإضافة دائرة متحركة
    _redCircleLayer = [CAShapeLayer layer];
    _redCircleLayer.fillColor = [UIColor clearColor].CGColor;
    _redCircleLayer.strokeColor = [UIColor redColor].CGColor;
    _redCircleLayer.lineWidth = 2.0;
    _redCircleLayer.opacity = 0.0;
    [_blurView.contentView.layer addSublayer:_redCircleLayer];

    [self updateViewConstraints];
    
    // إعداد الـ MENU بعد تحميل الواجهة
    timer(2.5, ^{
        setupMenu();
    });
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self startRedCircleAnimation];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self stopRedCircleAnimation];
}

- (void)startRedCircleAnimation {
    // إخفاء المربع الأحمر القديم
    if (_redSquareView) {
        _redSquareView.hidden = YES;
    }
    
    // إعداد الدائرة الحمراء
    CGFloat circleSize = 18.0;
    CGRect circleRect = CGRectMake(0, 0, circleSize, circleSize);
    
    UIBezierPath *circlePath = [UIBezierPath bezierPathWithOvalInRect:circleRect];
    _redCircleLayer.path = circlePath.CGPath;
    
    // تحريك الدائرة إلى المركز
    _redCircleLayer.position = CGPointMake(_blurView.bounds.size.width/2 - circleSize/2, 
                                         _blurView.bounds.size.height/2 - circleSize/2);
    
    // رسوم متحركة للظهور والاختفاء السلس
    CABasicAnimation *fadeInAnimation = [CABasicAnimation animationWithKeyPath:@"opacity"];
    fadeInAnimation.fromValue = @(0.0);
    fadeInAnimation.toValue = @(0.7);
    fadeInAnimation.duration = 0.8;
    fadeInAnimation.fillMode = kCAFillModeForwards;
    fadeInAnimation.removedOnCompletion = NO;
    
    // رسوم متحركة للدوران
    CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation"];
    rotationAnimation.fromValue = @(0.0);
    rotationAnimation.toValue = @(2 * M_PI);
    rotationAnimation.duration = 2.0;
    rotationAnimation.repeatCount = INFINITY;
    
    // مجموعة الرسوم المتحركة
    CAAnimationGroup *animationGroup = [CAAnimationGroup animation];
    animationGroup.animations = @[fadeInAnimation, rotationAnimation];
    animationGroup.duration = 2.0;
    animationGroup.repeatCount = INFINITY;
    
    [_redCircleLayer addAnimation:animationGroup forKey:@"redCircleAnimation"];
}

- (void)stopRedCircleAnimation {
    [_redCircleLayer removeAllAnimations];
    _redCircleLayer.opacity = 0.0;
}

- (void)updateViewConstraints {
    [super updateViewConstraints];

    [NSLayoutConstraint deactivateConstraints:_constraints];
    [_constraints removeAllObjects];

    CGFloat blurWidth = 40.0;
    CGFloat blurHeight = 40.0;
    CGFloat topMargin = 5.0;

    [_constraints addObjectsFromArray:@[
        [_blurView.widthAnchor constraintEqualToConstant:blurWidth],
        [_blurView.heightAnchor constraintEqualToConstant:blurHeight],
        [_blurView.centerXAnchor constraintEqualToAnchor:_contentView.centerXAnchor],
        [_blurView.centerYAnchor constraintEqualToAnchor:_contentView.centerYAnchor]
    ]];

    [_constraints addObjectsFromArray:@[
        [_blurView.topAnchor constraintEqualToAnchor:_contentView.topAnchor],
        [_blurView.bottomAnchor constraintEqualToAnchor:_contentView.bottomAnchor],
        [_blurView.leadingAnchor constraintEqualToAnchor:_contentView.leadingAnchor],
        [_blurView.trailingAnchor constraintEqualToAnchor:_contentView.trailingAnchor]
    ]];

    UILayoutGuide *safeArea = self.view.safeAreaLayoutGuide;
    [_constraints addObjectsFromArray:@[
        [_contentView.topAnchor constraintEqualToAnchor:safeArea.topAnchor constant:topMargin],
        [_contentView.centerXAnchor constraintEqualToAnchor:safeArea.centerXAnchor]
    ]];

    [NSLayoutConstraint activateConstraints:_constraints];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    
    // تحديث موضع الدائرة عندما يتغير تخطيط العرض
    if (_redCircleLayer) {
        CGFloat circleSize = 18.0;
        _redCircleLayer.position = CGPointMake(_blurView.bounds.size.width/2 - circleSize/2, 
                                             _blurView.bounds.size.height/2 - circleSize/2);
    }
}

- (void)removeAllAnimations {
    [_contentView.layer removeAllAnimations];
    [_blurView.layer removeAllAnimations];
    [_redCircleLayer removeAllAnimations];
    if (_redSquareView) {
        [_redSquareView.layer removeAllAnimations];
    }
}

@end