#import <UIKit/UIKit.h>

@interface UIWindow (Private)
- (unsigned int)_contextId;
@end