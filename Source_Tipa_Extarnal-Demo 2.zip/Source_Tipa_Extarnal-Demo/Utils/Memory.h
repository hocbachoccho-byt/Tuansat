//
//  Memory.h
//
//  Created by bphucc on 2025/05/25.
//

#import <Foundation/Foundation.h>
#import <mach/mach.h>
#import <sys/sysctl.h>

NS_ASSUME_NONNULL_BEGIN

typedef struct {
    vm_address_t start;
    vm_address_t end;
} AddrRange;

@interface MemoryUtils : NSObject

@property (nonatomic, strong, readonly) NSString *processName;
@property (nonatomic, readonly) pid_t processID;
@property (nonatomic, readonly) mach_port_t task;
@property (nonatomic, readonly) vm_map_offset_t baseAddress;
@property (nonatomic, readonly, getter=isValid) BOOL valid;

- (nullable instancetype)initWithProcessName:(NSString *)processName;

#pragma mark - Memory Reading
- (BOOL)readMemoryAtAddress:(vm_address_t)address buffer:(void *)buffer length:(vm_size_t)length;
- (nullable NSData *)readDataAtAddress:(vm_address_t)address length:(vm_size_t)length;

- (int8_t)readInt8AtAddress:(vm_address_t)address error:(NSError **)error;
- (uint8_t)readUInt8AtAddress:(vm_address_t)address error:(NSError **)error;
- (int16_t)readInt16AtAddress:(vm_address_t)address error:(NSError **)error;
- (uint16_t)readUInt16AtAddress:(vm_address_t)address error:(NSError **)error;
- (int32_t)readInt32AtAddress:(vm_address_t)address error:(NSError **)error;
- (uint32_t)readUInt32AtAddress:(vm_address_t)address error:(NSError **)error;
- (int64_t)readInt64AtAddress:(vm_address_t)address error:(NSError **)error;
- (uint64_t)readUInt64AtAddress:(vm_address_t)address error:(NSError **)error;
- (float)readFloatAtAddress:(vm_address_t)address error:(NSError **)error;
- (double)readDoubleAtAddress:(vm_address_t)address error:(NSError **)error;

#pragma mark - Memory Writing
- (BOOL)writeMemoryAtAddress:(vm_address_t)address value:(const void *)value length:(vm_size_t)length;
- (BOOL)writeDataAtAddress:(vm_address_t)address data:(NSData *)data;
- (BOOL)writeUInt32AtAddress:(vm_address_t)address value:(uint32_t)value;

- (BOOL)writeInt8AtAddress:(vm_address_t)address value:(int8_t)value error:(NSError **)error;
- (BOOL)writeUInt8AtAddress:(vm_address_t)address value:(uint8_t)value error:(NSError **)error;
- (BOOL)writeInt16AtAddress:(vm_address_t)address value:(int16_t)value error:(NSError **)error;
- (BOOL)writeUInt16AtAddress:(vm_address_t)address value:(uint16_t)value error:(NSError **)error;
- (BOOL)writeInt32AtAddress:(vm_address_t)address value:(int32_t)value error:(NSError **)error;
- (BOOL)writeUInt32AtAddress:(vm_address_t)address value:(uint32_t)value error:(NSError **)error;
- (BOOL)writeInt64AtAddress:(vm_address_t)address value:(int64_t)value error:(NSError **)error;
- (BOOL)writeUInt64AtAddress:(vm_address_t)address value:(uint64_t)value error:(NSError **)error;
- (BOOL)writeFloatAtAddress:(vm_address_t)address value:(float)value error:(NSError **)error;
- (BOOL)writeDoubleAtAddress:(vm_address_t)address value:(double)value error:(NSError **)error;

#pragma mark - Memory Scanning
- (NSArray<NSNumber *> *)scanMemoryForUInt32:(uint32_t)value inRange:(AddrRange)range;
- (NSArray<NSNumber *> *)scanMemoryForUInt64:(uint64_t)value inRange:(AddrRange)range;
- (NSArray<NSNumber *> *)scanMemoryForFloat:(float)value inRange:(AddrRange)range;
- (NSArray<NSNumber *> *)scanMemoryForFloatRange:(float)minValue max:(float)maxValue inRange:(AddrRange)range;
- (NSArray<NSNumber *> *)scanMemoryForData:(NSData *)data inRange:(AddrRange)range;
- (BOOL)verifyNearbyValues:(vm_address_t)baseAddress offsets:(NSArray<NSNumber *> *)offsets values:(NSArray<NSNumber *> *)values;

@end

NS_ASSUME_NONNULL_END